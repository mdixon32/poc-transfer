#import "RNSTabsScreenComponentViewManager.h"

#if !RCT_NEW_ARCH_ENABLED
#import "RNSTabsScreenComponentView.h"
#endif // !RCT_NEW_ARCH_ENABLED

@implementation RNSTabsScreenComponentViewManager

// TODO: This seems to be legacy arch only - remove when no longer needed

RCT_EXPORT_MODULE(RNSTabsScreenManager)

#if !RCT_NEW_ARCH_ENABLED
- (UIView *)view
{
  // This uses main initializer for Fabric implementation.
  return [[RNSTabsScreenComponentView alloc] initWithFrame:CGRectZero];
}

RCT_EXPORT_VIEW_PROPERTY(tabKey, NSString);

RCT_REMAP_VIEW_PROPERTY(isFocused, isSelectedScreen, BOOL);
RCT_EXPORT_VIEW_PROPERTY(title, NSString);
RCT_EXPORT_VIEW_PROPERTY(orientation, RNSOrientation);
RCT_EXPORT_VIEW_PROPERTY(badgeValue, NSString);

RCT_EXPORT_VIEW_PROPERTY(tabBarItemTestID, NSString);
RCT_EXPORT_VIEW_PROPERTY(tabBarItemAccessibilityLabel, NSString);

RCT_EXPORT_VIEW_PROPERTY(standardAppearance, NSDictionary);
RCT_EXPORT_VIEW_PROPERTY(scrollEdgeAppearance, NSDictionary);

RCT_EXPORT_VIEW_PROPERTY(iconType, RNSTabsIconType);
RCT_EXPORT_VIEW_PROPERTY(iconImageSource, RCTImageSource);
RCT_EXPORT_VIEW_PROPERTY(iconResourceName, NSString);
RCT_EXPORT_VIEW_PROPERTY(selectedIconImageSource, RCTImageSource);
RCT_EXPORT_VIEW_PROPERTY(selectedIconResourceName, NSString);

RCT_EXPORT_VIEW_PROPERTY(overrideScrollViewContentInsetAdjustmentBehavior, BOOL);

RCT_EXPORT_VIEW_PROPERTY(bottomScrollEdgeEffect, RNSScrollEdgeEffect);
RCT_EXPORT_VIEW_PROPERTY(leftScrollEdgeEffect, RNSScrollEdgeEffect);
RCT_EXPORT_VIEW_PROPERTY(rightScrollEdgeEffect, RNSScrollEdgeEffect);
RCT_EXPORT_VIEW_PROPERTY(topScrollEdgeEffect, RNSScrollEdgeEffect);

RCT_EXPORT_VIEW_PROPERTY(userInterfaceStyle, UIUserInterfaceStyle);

RCT_EXPORT_VIEW_PROPERTY(systemItem, RNSTabsScreenSystemItem);

RCT_EXPORT_VIEW_PROPERTY(specialEffects, NSDictionary);

RCT_EXPORT_VIEW_PROPERTY(onWillAppear, RCTDirectEventBlock);
RCT_EXPORT_VIEW_PROPERTY(onWillDisappear, RCTDirectEventBlock);
RCT_EXPORT_VIEW_PROPERTY(onDidAppear, RCTDirectEventBlock);
RCT_EXPORT_VIEW_PROPERTY(onDidDisappear, RCTDirectEventBlock);

#endif // !RCT_NEW_ARCH_ENABLED

@end
